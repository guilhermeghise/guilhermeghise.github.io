// App.js
import React, { useState, useEffect, useRef } from 'react';
import { BrowserRouter as Router, Routes, Route, useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { ChevronLeft, ChevronRight, ChevronDown } from 'lucide-react';
import { projects } from './data'; // Puxa os dados atualizados
import ProjectPage from './ProjectPage';
import './App.css';

const appleEase = [0.22, 1, 0.36, 1];

// A página inicial antiga se torna um componente
function Home() {
  const [index, setIndex] = useState(0);
  const navigate = useNavigate(); // Hook de navegação do React Router

  const heroRef = useRef(null);
  const aboutRef = useRef(null);
  const projectsRef = useRef(null);
  const contactRef = useRef(null);

  const scrollTo = (ref) => ref.current.scrollIntoView({ behavior: 'smooth' });

  const handleNext = () => setIndex((prev) => (prev === projects.length - 1 ? 0 : prev + 1));
  const handlePrev = () => setIndex((prev) => (prev === 0 ? projects.length - 1 : prev - 1));

  useEffect(() => {
    const timer = setInterval(() => handleNext(), 3500);
    return () => clearInterval(timer);
  }, []);

  const getOffset = (i) => {
    let diff = i - index;
    if (diff > Math.floor(projects.length / 2)) diff -= projects.length;
    if (diff < -Math.floor(projects.length / 2)) diff += projects.length;
    return diff;
  };

  return (
    <div className="portfolio-container">
      <nav className="navbar">
        <div className="nav-links">
          <button onClick={() => scrollTo(heroRef)}>Início</button>
          <button onClick={() => scrollTo(aboutRef)}>Sobre</button>
          <button onClick={() => scrollTo(projectsRef)}>Projetos</button>
          <button onClick={() => scrollTo(contactRef)}>Contato</button>
        </div>
      </nav>

      <section ref={heroRef} className="hero">
        <motion.h1 initial={{ opacity: 0, scale: 0.95 }} whileInView={{ opacity: 1, scale: 1 }} transition={{ duration: 1.5, ease: appleEase }}>
          Guilherme Ghise
        </motion.h1>
        <div className="scroll-hint"><ChevronDown size={28} strokeWidth={1.5} /></div>
      </section>

      <section ref={aboutRef}>
        <div className="about-grid">
          <motion.div className="about-text" initial={{ opacity: 0, x: -60 }} whileInView={{ opacity: 1, x: 0 }} transition={{ duration: 1.2, ease: appleEase }}>
            <h2>Sobre mim</h2>
            <p>Desenvolvedor focado no ecossistema Apple...</p>
          </motion.div>
        </div>
      </section>

      <section ref={projectsRef}>
        <motion.h2 initial={{ opacity: 0 }} whileInView={{ opacity: 1 }} style={{ fontSize: '2.5rem', marginBottom: '10px' }}>
          Meus Apps
        </motion.h2>

        <div className="carousel-wrapper">
          <button className="carousel-button btn-left" onClick={handlePrev}><ChevronLeft size={28} strokeWidth={1.5} /></button>
          
          <div className="carousel-track">
            {projects.map((project, i) => {
              const offset = getOffset(i);
              
              let xPosition = "0%";
              let scaleValue = 1;
              let zIndexValue = 10;
              let filterValue = "blur(0px) brightness(1)";
              let opacityValue = 1;
              // AQUI DEFINIMOS SE ELE É CLICÁVEL (Só clica se estiver no centro)
              const isCenter = offset === 0; 

              if (offset === -1) { xPosition = "-115%"; scaleValue = 0.85; zIndexValue = 5; filterValue = "blur(4px) brightness(0.4)"; }
              else if (offset === 1) { xPosition = "115%"; scaleValue = 0.85; zIndexValue = 5; filterValue = "blur(4px) brightness(0.4)"; }
              else if (offset !== 0) { xPosition = offset > 0 ? "200%" : "-200%"; scaleValue = 0.6; zIndexValue = 1; opacityValue = 0; filterValue = "blur(10px)"; }

              return (
                <motion.div 
                  key={project.id}
                  className="iphone-frame"
                  // Dispara a navegação apenas se for o item central
                  onClick={() => isCenter && navigate(`/projeto/${project.slug}`)}
                  style={{ cursor: isCenter ? 'pointer' : 'default' }}
                  animate={{ x: xPosition, scale: scaleValue, zIndex: zIndexValue, filter: filterValue, opacity: opacityValue }}
                  transition={{ duration: 0.7, ease: appleEase }}
                >
                  <div className="iphone-content">
                    <h3>{project.title}</h3>
                    <p>{project.desc}</p>
                  </div>
                </motion.div>
              );
            })}
          </div>

          <button className="carousel-button btn-right" onClick={handleNext}><ChevronRight size={28} strokeWidth={1.5} /></button>
        </div>
      </section>

      <section ref={contactRef}>
        <motion.h2 className="contact-title" initial={{ opacity: 0, y: 30 }} whileInView={{ opacity: 1, y: 0 }} transition={{ duration: 1.2, ease: appleEase }}>
          Quer conversar comigo?
        </motion.h2>
      </section>
    </div>
  );
}

// O App Principal agora é o Roteador
function App() {
  return (
    <Router>
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/projeto/:slug" element={<ProjectPage />} />
      </Routes>
    </Router>
  );
}

export default App;