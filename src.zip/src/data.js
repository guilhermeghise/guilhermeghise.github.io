export const projects = [
  { 
    id: 1, 
    slug: "coffee-overflow",
    title: "Coffee Overflow", 
    desc: "iOS Development Workflow",
    logo: "https://via.placeholder.com/150", 
    shortDesc: "Ferramenta essencial para desenvolvedores iOS gerenciarem seus projetos com foco e organização.",
    fullDesc: "O Coffee Overflow foi projetado para ser a central de comando de qualquer desenvolvedor do ecossistema Apple. Ele traz métricas de produtividade, integração com repositórios e alertas inteligentes baseados na sua rotina de código.",
    media: [
      { type: "video", src: "https://www.w3schools.com/html/mov_bbb.mp4" }, 
      { type: "image", src: "https://via.placeholder.com/250x540/1c1c1e/ffffff?text=Mock+1" },
      { type: "image", src: "https://via.placeholder.com/250x540/1c1c1e/ffffff?text=Mock+2" },
      { type: "image", src: "https://via.placeholder.com/250x540/1c1c1e/ffffff?text=Mock+3" }
    ],
    technologies: ["Swift", "SwiftUI", "CoreData", "CloudKit"],
    team: [
      { name: "Guilherme Ghise", role: "Developer", linkedin: "https://linkedin.com/in/seu-perfil" },
      { name: "Steve Jobs", role: "Designer", linkedin: "https://linkedin.com/in/steve" }
    ]
  },
  
  // Adicione os outros projetos seguindo esse mesmo modelo...
];