// ProjectPage.js
import React, { useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';
import { projects } from './data';
import { ChevronLeft } from 'lucide-react';
import { motion } from 'framer-motion';
import './ProjectPage.css';

const fadeUp = {
  hidden: { opacity: 0, y: 20 },
  visible: { opacity: 1, y: 0, transition: { duration: 0.8, ease: [0.22, 1, 0.36, 1] } }
};

const staggerContainer = {
  hidden: { opacity: 0 },
  visible: { opacity: 1, transition: { staggerChildren: 0.1 } }
};

function ProjectPage() {
  const { slug } = useParams();
  const project = projects.find(p => p.slug === slug);

  useEffect(() => {
    window.scrollTo(0, 0);
  }, []);

  if (!project) return <div className="error-page">Projeto não encontrado.</div>;

  return (
    <div className="project-detail-page">
      {/* Botão de Voltar estilo iOS */}
      <nav className="detail-nav">
        <Link to="/" className="nav-back-button">
          <ChevronLeft size={24} strokeWidth={2.5} />
          <span>Projetos</span>
        </Link>
      </nav>

      <motion.div 
        className="project-content"
        variants={staggerContainer}
        initial="hidden"
        animate="visible"
      >
        {/* HERO SECTION */}
        <motion.header className="detail-hero" variants={fadeUp}>
          <div className="hero-logo-container">
            <img src={project.logo} alt={`Logo ${project.title}`} className="hero-logo" />
          </div>
          <h1 className="hero-title">{project.title}</h1>
          <p className="hero-subtitle">{project.shortDesc}</p>
        </motion.header>

        {/* MÍDIA (Mocks mais coesos com a Home) */}
        <motion.section className="media-showcase" variants={fadeUp}>
          <div className="scroll-track">
            {project.media.map((item, index) => (
              <div key={index} className="mockup-container">
                <div className="mockup-frame">
                  <div className="mockup-island"></div>
                  {item.type === 'video' ? (
                    <video src={item.src} autoPlay loop muted playsInline className="mockup-content" />
                  ) : (
                    <img src={item.src} alt={`Tela ${index}`} className="mockup-content" />
                  )}
                </div>
              </div>
            ))}
          </div>
        </motion.section>

        {/* BENTO GRID (Limpo e Minimalista) */}
        <motion.section className="bento-layout" variants={fadeUp}>
          
          <div className="bento-card col-span-2">
            <h3>A Visão</h3>
            <p>{project.fullDesc}</p>
          </div>

          <div className="bento-card">
            <h3>Tecnologias</h3>
            <div className="tech-pills">
              {project.technologies.map((tech, i) => (
                <span key={i} className="tech-pill">{tech}</span>
              ))}
            </div>
          </div>

          <div className="bento-card">
            <h3>Criadores</h3>
            <div className="team-bento-list">
              {project.team.map((member, i) => (
                <a key={i} href={member.linkedin} target="_blank" rel="noreferrer" className="team-bento-item">
                  <div className="member-info">
                    <span className="member-name">{member.name}</span>
                    <span className="member-role">{member.role}</span>
                  </div>
                  <div className="member-link-icon">↗</div>
                </a>
              ))}
            </div>
          </div>

        </motion.section>
      </motion.div>
    </div>
  );
}

export default ProjectPage;